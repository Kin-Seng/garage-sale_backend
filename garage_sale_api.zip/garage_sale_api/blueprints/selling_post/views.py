from flask import Blueprint,jsonify
from models.selling_post import SellingPost

selling_post_api_blueprint = Blueprint('selling_post_api',
                             __name__,
                             template_folder='templates')

@selling_post_api_blueprint.route('/', methods=['GET'])
def index():
    return "Selling Post API"

@selling_post_api_blueprint.route('/market', methods=['GET'])
def marketList_show():
    marketlist = SellingPost.select()
    
    return jsonify(
       [
           {
                "product_category": post.username,
                "username": post.username,
                "email": post.email,
                "profile_pic": post.profile_pic,
            } for post in marketlist
        ]
    ) 

@selling_post_api_blueprint.route('/create', methods=['GET'])
def sp_create():

   
    # u = Users(username=username, email=email, pwd=generate_password_hash(password),profile=profile,age=age,address=address, phone_no = phoneNo)
    # u.save()

    return "Selling Post create API"

@selling_post_api_blueprint.route('/delete', methods=['GET'])
def sp_delete():
    
    # p = SellingPost.delete().where(SellingPost.seller_id == current_user, SellingPost.id == SellingPost_id from react ).execute()

    return "Selling Post delete API"